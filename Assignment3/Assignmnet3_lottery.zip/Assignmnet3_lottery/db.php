<?php

$num = $_POST['num'];


echo "<p>Youe Number:</p>";
echo "<p>".$num."</p>";


echo "<p>Your Number is:</p>";

$secret = rand(1,10);

echo "<p>Secret Number:".$secret."</p>";

if($num == $secret){


    echo "<p>equal</p>";


}

if($num > $secret){


    echo "<p>Less</p>";


}

if($num < $secret){


    echo "<p>Greater</p>";


}









?>



<?php

$sentence = $_POST['sentence'];


$arr =  explode(" ", $sentence);
    
    
$noOfWords = 0 ;
$noOfChar = 0;

foreach($arr as $v){
    
    $number = strlen($v);
    $noOfChar = $number + $noOfChar + $noOfWords;
    $noOfWords = $noOfWords +1;
}

echo "<p>The sentence you entered is :</p>";
echo "<p>".$sentence."</p>";


echo "<p>It is composed of : </p>";

echo "<ul>";

echo  "<li>".$noOfWords." different words</li>";

echo "<li>". $noOfChar ." characters (including space)</li>";

echo "</ul>";







?>



<?php

$diameter = $_POST['diameter'];
$sideA = $_POST['sideA'];
$sideB = $_POST['sideB'];

$radius = $diameter/2 ;
$Hypotenusedouble = ($sideA * $sideA) +  ($sideB * $sideB);




echo "<p>Date:</p>";
echo "<p>".date("l, F jS  Y ")."</p>";


echo "<p>Time:</p>";
echo "<p>". date("h:i a")."</p>";

echo "<p>Your table details:</p>";
echo "<p>Diamter:".$diameter."</p>";
echo "<p>Circumference:". 3.14 * $diameter."</p>";
echo "<p>Surface area:". 3.14 * $radius * $radius."</p>";


echo "<p>The length of traingle hypotenuse:</p>";
echo "<p>Side A:".$sideA."</p>";
echo "<p>Side B:".$sideB."</p>";
echo "<p>Hypotenuse:".sqrt($Hypotenusedouble)."</p>";









?>


